# Contributor Covenant Code of Conduct

All of the projects under the spraybot organization follow the same
Code of Conduct. Please check out `CODE_OF_CONDUCT.md` at the
[spraybot/code-of-conduct](https://github.com/spraybot/code-of-conduct)
repository.