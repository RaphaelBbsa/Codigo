package br.com.rporto.domain;

public class Produto {

}
