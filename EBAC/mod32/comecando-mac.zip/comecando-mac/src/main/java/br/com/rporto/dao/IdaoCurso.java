package br.com.rporto.dao;

import br.com.rporto.domain.Curso;

public interface IdaoCurso {

    public Curso cadastrar(Curso curso); 

}
