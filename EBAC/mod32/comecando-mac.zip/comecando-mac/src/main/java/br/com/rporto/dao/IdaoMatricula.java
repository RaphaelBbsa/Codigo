package br.com.rporto.dao;

import br.com.rporto.domain.Matricula;

public interface IdaoMatricula {

    public Matricula cadastrar(Matricula matricula);
}
